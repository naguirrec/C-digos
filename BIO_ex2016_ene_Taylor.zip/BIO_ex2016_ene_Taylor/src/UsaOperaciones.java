public class UsaOperaciones {
	public static void main(String[] args) {
		double x = 1.0;
		int n = 5;
		double numeroE = Math.E;
		double numeroEaprox = Operaciones.serieTaylor(x, n);
		System.out.println("N�mero e = " + numeroE);
		System.out.println("Aproximaci�n del n�mero e = " + numeroEaprox);
	}
}
