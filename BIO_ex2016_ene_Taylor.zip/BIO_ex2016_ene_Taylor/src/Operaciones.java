public class Operaciones {
	public static double serieTaylor(double x, int n) {
		double suma = 1.0;
		double at = 1.0;
		for(int t=1;t<=n;t++) {
			at=at*x/t;			
			suma+=at;
		}
		return suma;
	}
}
