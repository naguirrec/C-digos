package es.upm.dit.prog.practica5;

public interface SelectorSatelite {
	public boolean seleccionar(Satelite s);
}
