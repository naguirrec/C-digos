package es.upm.dit.prog.practica5;

public class SelectorSateliteTrue implements SelectorSatelite{
	
	public boolean seleccionar(Satelite s) {
		return s!=null;
	}
	
}
