package es.upm.dit.prog.practica4;

public class SelectorSateliteTrue implements SelectorSatelite{
	
	public boolean seleccionar(Satelite s) {
		return s!=null;
	}
	
}
