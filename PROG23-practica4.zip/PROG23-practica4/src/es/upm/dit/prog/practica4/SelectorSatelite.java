package es.upm.dit.prog.practica4;

public interface SelectorSatelite {
	public boolean seleccionar(Satelite s);
}
